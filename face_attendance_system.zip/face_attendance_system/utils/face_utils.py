# utils/face_utils.py
import face_recognition
import numpy as np
import cv2
import pickle
from PIL import Image

class FaceRecognitionUtils:
    """Utility class for face encoding and recognition"""
    
    @staticmethod
    def get_face_encoding(image_path):
        """
        Extract face encoding from image file
        Returns: numpy array of face encoding or None
        """
        try:
            # Load image
            image = face_recognition.load_image_file(image_path)
            
            # Get face encodings
            face_encodings = face_recognition.face_encodings(image)
            
            if len(face_encodings) == 0:
                print("No face detected in image")
                return None
            
            if len(face_encodings) > 1:
                print("Multiple faces detected, using first face")
            
            return face_encodings[0]
            
        except Exception as e:
            print(f"Error encoding face: {e}")
            return None
    
    @staticmethod
    def encode_for_database(face_encoding):
        """
        Convert numpy array to binary for SQL Server storage
        """
        return pickle.dumps(face_encoding)
    
    @staticmethod
    def decode_from_database(binary_data):
        """
        Convert binary data from database back to numpy array
        """
        return pickle.loads(binary_data)
    
    @staticmethod
    def compare_faces(known_encoding, face_encoding, tolerance=0.6):
        """
        Compare two face encodings
        Returns: (match, distance)
        """
        if known_encoding is None or face_encoding is None:
            return False, 1.0
        
        # Calculate face distance
        face_distance = face_recognition.face_distance([known_encoding], face_encoding)[0]
        
        # Check if match
        match = face_distance <= tolerance
        
        # Convert distance to confidence score (0-100)
        confidence = (1 - face_distance) * 100
        
        return match, confidence
    
    @staticmethod
    def detect_and_encode_frame(frame):
        """
        Detect faces in video frame and return encodings
        Returns: list of (face_location, face_encoding) tuples
        """
        # Convert BGR to RGB (OpenCV uses BGR)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Detect faces
        face_locations = face_recognition.face_locations(rgb_frame)
        face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
        
        return list(zip(face_locations, face_encodings))
    
    @staticmethod
    def draw_face_box(frame, face_location, name, confidence):
        """
        Draw bounding box and name on frame
        """
        top, right, bottom, left = face_location
        
        # Draw rectangle
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
        
        # Draw label background
        cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 255, 0), cv2.FILLED)
        
        # Draw text
        font = cv2.FONT_HERSHEY_DUPLEX
        text = f"{name} ({confidence:.1f}%)"
        cv2.putText(frame, text, (left + 6, bottom - 6), font, 0.6, (0, 0, 0), 1)
        
        return frame
    
    @staticmethod
    def resize_image(image_path, max_size=(800, 800)):
        """
        Resize image while maintaining aspect ratio
        """
        img = Image.open(image_path)
        img.thumbnail(max_size, Image.Resampling.LANCZOS)
        img.save(image_path)
        return image_path
    
    @staticmethod
    def validate_image(image_path):
        """
        Validate if image contains a detectable face
        Returns: (is_valid, message)
        """
        try:
            image = face_recognition.load_image_file(image_path)
            face_locations = face_recognition.face_locations(image)
            
            if len(face_locations) == 0:
                return False, "No face detected in image"
            elif len(face_locations) > 1:
                return False, "Multiple faces detected. Please use image with single face"
            else:
                return True, "Valid face image"
                
        except Exception as e:
                            return False, f"Error validating image: {str(e)}"