# utils/db_config.py
import pyodbc
import os
from dotenv import load_dotenv

load_dotenv()

class DatabaseConfig:
    """Database connection manager for SQL Server"""
    
    def __init__(self):
        self.server = os.getenv('DB_SERVER')
        self.database = os.getenv('DB_NAME')
        self.username = os.getenv('DB_USER')
        self.password = os.getenv('DB_PASSWORD')
        self.driver = os.getenv('DB_DRIVER', 'ODBC Driver 17 for SQL Server')
        
    def get_connection_string(self):
        """Build SQL Server connection string"""
        # Check if using Windows Authentication
        trusted = os.getenv('DB_TRUSTED_CONNECTION', 'no').lower()
        
        if trusted == 'yes' or trusted == 'true':
            # Windows Authentication (No username/password needed)
            return (
                f'DRIVER={{{self.driver}}};'
                f'SERVER={self.server};'
                f'DATABASE={self.database};'
                f'Trusted_Connection=yes;'
            )
        else:
            # SQL Server Authentication (For Production with username/password)
            return (
                f'DRIVER={{{self.driver}}};'
                f'SERVER={self.server};'
                f'DATABASE={self.database};'
                f'UID={self.username};'
                f'PWD={self.password};'
                f'Encrypt=yes;'
                f'TrustServerCertificate=yes;'
            )
    
    def get_connection(self):
        """Get database connection"""
        try:
            conn = pyodbc.connect(self.get_connection_string())
            return conn
        except pyodbc.Error as e:
            print(f"Database connection error: {e}")
            raise
    
    def execute_query(self, query, params=None, fetch=False):
        """Execute SQL query with error handling"""
        conn = None
        cursor = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            
            if fetch:
                result = cursor.fetchall()
                return result
            else:
                conn.commit()
                return cursor.rowcount
                
        except pyodbc.Error as e:
            if conn:
                conn.rollback()
            print(f"Query execution error: {e}")
            raise
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
    
    def execute_stored_procedure(self, proc_name, params=None):
        """Execute stored procedure"""
        conn = None
        cursor = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            if params:
                cursor.execute(f"EXEC {proc_name} {','.join(['?']*len(params))}", params)
            else:
                cursor.execute(f"EXEC {proc_name}")
            
            result = cursor.fetchall()
            conn.commit()
            return result
            
        except pyodbc.Error as e:
            if conn:
                conn.rollback()
            print(f"Stored procedure error: {e}")
            raise
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

# Global database instance
db = DatabaseConfig()