# utils/__init__.py
from .db_config import db, DatabaseConfig
from .face_utils import FaceRecognitionUtils

face_utils = FaceRecognitionUtils()

__all__ = ['db', 'DatabaseConfig', 'face_utils', 'FaceRecognitionUtils']