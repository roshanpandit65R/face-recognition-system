# main.py
"""
User Registration Application
Allows administrators to register new employees with face images
"""

from flask import Flask, render_template, request, jsonify
import os
from werkzeug.utils import secure_filename
from datetime import datetime
from utils.db_config import db
from utils import face_utils
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-this')
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

# Create upload folder
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


@app.route('/')
def index():
    return render_template('register.html')


@app.route('/register', methods=['POST'])
def register_user():
    try:
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()

        if not name:
            return jsonify({'success': False, 'message': 'Name is required'}), 400

        if 'image' not in request.files:
            return jsonify({'success': False, 'message': 'No image uploaded'}), 400

        file = request.files['image']

        if file.filename == '':
            return jsonify({'success': False, 'message': 'No image selected'}), 400

        if not allowed_file(file.filename):
            return jsonify({'success': False, 'message': 'Invalid file type'}), 400

        # Save image
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = secure_filename(f"{name.replace(' ', '_')}_{timestamp}.jpg")
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Image processing
        face_utils.resize_image(filepath)

        is_valid, message = face_utils.validate_image(filepath)
        if not is_valid:
            os.remove(filepath)
            return jsonify({'success': False, 'message': message}), 400

        face_encoding = face_utils.get_face_encoding(filepath)
        if face_encoding is None:
            os.remove(filepath)
            return jsonify({'success': False, 'message': 'Face encoding failed'}), 400

        encoded_binary = face_utils.encode_for_database(face_encoding)

        # ✅ FIXED QUERY (dbo.Users)
        query = """
        INSERT INTO dbo.Users (name, email, face_encoding, image_path)
        VALUES (?, ?, ?, ?)
        """

        db.execute_query(
            query,
            (name, email, encoded_binary, f'/static/uploads/{filename}')
        )

        return jsonify({
            'success': True,
            'message': f'User {name} registered successfully',
            'image_path': f'/static/uploads/{filename}'
        })

    except Exception as e:
        print(f"Registration error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/users')
def list_users():
    try:
        # ✅ FIXED QUERY
        query = """
        SELECT user_id, name, email, registered_at, is_active
        FROM dbo.Users
        ORDER BY registered_at DESC
        """
        users = db.execute_query(query, fetch=True)

        data = []
        for u in users:
            data.append({
                'user_id': u[0],
                'name': u[1],
                'email': u[2],
                'registered_at': u[3].strftime('%Y-%m-%d %H:%M:%S') if u[3] else '',
                'is_active': bool(u[4])
            })

        return jsonify({'success': True, 'users': data})

    except Exception as e:
        print(f"Error fetching users: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/delete_user/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    try:
        # ✅ FIXED QUERY
        query = "UPDATE dbo.Users SET is_active = 0 WHERE user_id = ?"
        db.execute_query(query, (user_id,))

        return jsonify({'success': True, 'message': 'User deactivated successfully'})

    except Exception as e:
        print(f"Error deleting user: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


if __name__ == '__main__':
    print("=" * 60)
    print("FACE ATTENDANCE SYSTEM - USER REGISTRATION")
    print("Server running at: http://localhost:5000")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5000, debug=True)
