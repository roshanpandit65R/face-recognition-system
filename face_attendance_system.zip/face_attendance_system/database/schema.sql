-- database/schema.sql
-- SQL Server Database Schema for Face Attendance System

-- Create Database
CREATE DATABASE AttendanceDB;
GO

USE AttendanceDB;
GO

-- Table: Users (Store registered employees)
CREATE TABLE Users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    email NVARCHAR(100) UNIQUE,
    face_encoding VARBINARY(MAX) NOT NULL,
    image_path NVARCHAR(255),
    registered_at DATETIME DEFAULT GETDATE(),
    is_active BIT DEFAULT 1
);

-- Table: Attendance (Store daily attendance records)
CREATE TABLE Attendance (
    attendance_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    check_in_time DATETIME DEFAULT GETDATE(),
    attendance_date DATE DEFAULT CAST(GETDATE() AS DATE),
    status NVARCHAR(20) DEFAULT 'Present',
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    CONSTRAINT UQ_User_Date UNIQUE(user_id, attendance_date)
);

-- Table: Attendance_Logs (Detailed logs for audit)
CREATE TABLE Attendance_Logs (
    log_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    action NVARCHAR(50),
    timestamp DATETIME DEFAULT GETDATE(),
    confidence_score FLOAT,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- Index for faster queries
CREATE INDEX idx_attendance_date ON Attendance(attendance_date);
CREATE INDEX idx_user_active ON Users(is_active);
CREATE INDEX idx_logs_timestamp ON Attendance_Logs(timestamp);

-- View: Today's Attendance Summary
CREATE VIEW vw_TodayAttendance AS
SELECT 
    u.user_id,
    u.name,
    a.check_in_time,
    a.status
FROM Users u
LEFT JOIN Attendance a ON u.user_id = a.user_id 
    AND a.attendance_date = CAST(GETDATE() AS DATE)
WHERE u.is_active = 1;
GO

-- Stored Procedure: Mark Attendance
CREATE PROCEDURE sp_MarkAttendance
    @user_id INT,
    @confidence FLOAT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @today DATE = CAST(GETDATE() AS DATE);
    DECLARE @existing INT;
    
    -- Check if already marked today
    SELECT @existing = COUNT(*) 
    FROM Attendance 
    WHERE user_id = @user_id AND attendance_date = @today;
    
    IF @existing = 0
    BEGIN
        -- Insert attendance
        INSERT INTO Attendance (user_id, attendance_date, check_in_time, status)
        VALUES (@user_id, @today, GETDATE(), 'Present');
        
        -- Log the action
        INSERT INTO Attendance_Logs (user_id, action, confidence_score)
        VALUES (@user_id, 'CHECK_IN', @confidence);
        
        SELECT 'SUCCESS' AS Result, 'Attendance marked successfully' AS Message;
    END
    ELSE
    BEGIN
        SELECT 'DUPLICATE' AS Result, 'Already marked today' AS Message;
    END
END;
GO

-- Sample data insertion (for testing)
-- INSERT INTO Users (name, email, face_encoding, image_path)
-- VALUES ('John Doe', 'john@company.com', 0x..., '/static/uploads/john.jpg');

PRINT 'Database schema created successfully!';




-- FORCE CREATE USERS TABLE

IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL
    DROP TABLE dbo.Users;
GO

CREATE TABLE dbo.Users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    email NVARCHAR(100) UNIQUE,
    face_encoding VARBINARY(MAX) NOT NULL,
    image_path NVARCHAR(255),
    registered_at DATETIME DEFAULT GETDATE(),
    is_active BIT DEFAULT 1
);
GO


USE AttendanceDB;
GO

-- ATTENDANCE TABLE
CREATE TABLE dbo.Attendance (
    attendance_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL,
    check_in_time DATETIME DEFAULT GETDATE(),
    attendance_date DATE DEFAULT CAST(GETDATE() AS DATE),
    status NVARCHAR(20) DEFAULT 'Present',
    CONSTRAINT FK_Attendance_User
        FOREIGN KEY (user_id) REFERENCES dbo.Users(user_id),
    CONSTRAINT UQ_User_Date UNIQ
    
    
    UE (user_id, attendance_date)
);
GO



SELECT * FROM dbo.Users;
SELECT * FROM dbo.Attendance;

DELETE FROM Attendance;


USE AttendanceDB;
GO

CREATE OR ALTER PROCEDURE dbo.sp_MarkAttendance
    @user_id INT,
    @confidence FLOAT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @today DATE = CAST(GETDATE() AS DATE);

    IF NOT EXISTS (
        SELECT 1 FROM dbo.Attendance
        WHERE user_id = @user_id
        AND attendance_date = @today
    )
    BEGIN
        INSERT INTO dbo.Attendance (user_id, check_in_time, attendance_date, status)
        VALUES (@user_id, GETDATE(), @today, 'Present');

        SELECT 'SUCCESS' AS Result, 'Attendance marked successfully' AS Message;
    END
    ELSE
    BEGIN
        SELECT 'DUPLICATE' AS Result, 'Attendance already marked today' AS Message;
    END
END;
GO



