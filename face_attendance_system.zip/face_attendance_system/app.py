"""
Real-Time Face Attendance Scanner
Continuous camera feed that automatically detects and marks attendance
"""

from flask import Flask, render_template, Response, jsonify
import cv2
import numpy as np
from datetime import datetime, date
import threading
import time
from collections import deque
from utils.db_config import db
from utils import face_utils
from dotenv import load_dotenv
import os
import face_recognition

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-this')

# Global variables
camera = None
known_faces = []
known_names = []
known_ids = []

# Cooldown management
SCAN_COOLDOWN = 2  # 2 seconds cooldown after successful scan
RECOGNITION_COOLDOWN = 5  # seconds before same person can be recognized again

# Track scan cooldown
last_scan_time = 0
scan_cooldown_active = False
cooldown_end_time = 0

# Track individual user cooldowns
user_cooldowns = {}

class CameraStream:
    """Handle camera streaming and face recognition"""
    
    def __init__(self):
        self.video = cv2.VideoCapture(0)
        self.video.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.video.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self.lock = threading.Lock()
        self.last_frame = None
        self.scan_in_progress = False
        self.attendance_marked = False
        
    def __del__(self):
        if self.video.isOpened():
            self.video.release()
    
    def get_frame(self):
        """Capture and process frame"""
        with self.lock:
            success, frame = self.video.read()
            if not success:
                return None
            
            # Flip frame horizontally for mirror effect
            frame = cv2.flip(frame, 1)
            
            # Check if we're in cooldown period
            global scan_cooldown_active, last_scan_time
            
            # Only process faces if not in cooldown
            current_time = time.time()
            if not scan_cooldown_active and not self.scan_in_progress:
                # Process face recognition
                frame, attendance_marked = self.process_faces(frame, current_time)
                
                # If attendance was marked, start cooldown
                if attendance_marked:
                    self.attendance_marked = True
                    scan_cooldown_active = True
                    last_scan_time = current_time
                    cooldown_end_time = current_time + SCAN_COOLDOWN
            else:
                # In cooldown - just draw overlay
                frame = self.draw_cooldown_overlay(frame, current_time)
            
            # Encode frame as JPEG
            ret, buffer = cv2.imencode('.jpg', frame)
            if not ret:
                return None
            
            return buffer.tobytes()
    
    def process_faces(self, frame, current_time):
        """Detect and recognize faces in frame"""
        attendance_marked = False
        
        # Check if any scan is already in progress globally
        global scan_cooldown_active
        if scan_cooldown_active:
            return frame, False
        
        # Detect faces (use smaller frame for speed)
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
        
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
        
        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            # Scale back up face locations
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4
            
            name = "Unknown"
            confidence = 0
            user_id = None
            
            # Compare with known faces
            if len(known_faces) > 0:
                matches = face_recognition.compare_faces(known_faces, face_encoding, tolerance=0.6)
                face_distances = face_recognition.face_distance(known_faces, face_encoding)
                
                if len(face_distances) > 0:
                    best_match_index = np.argmin(face_distances)
                    
                    if matches[best_match_index]:
                        name = known_names[best_match_index]
                        user_id = known_ids[best_match_index]
                        confidence = (1 - face_distances[best_match_index]) * 100
                        
                        # Check user-specific cooldown
                        if user_id not in user_cooldowns or \
                           (current_time - user_cooldowns[user_id]) > RECOGNITION_COOLDOWN:
                            
                            # Mark attendance
                            if self.mark_attendance(user_id, confidence):
                                attendance_marked = True
                                user_cooldowns[user_id] = current_time
                                # Set scan in progress to prevent multiple scans
                                self.scan_in_progress = True
            
            # Draw face box with color coding
            if user_id and attendance_marked:
                color = (0, 255, 0)  # Green for successful scan
                status_text = "SCANNED"
            elif user_id:
                color = (0, 255, 255)  # Yellow for recognized but not scanned
                status_text = "RECOGNIZED"
            else:
                color = (0, 0, 255)  # Red for unknown
                status_text = "UNKNOWN"
            
            # Draw rectangle
            cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
            cv2.rectangle(frame, (left, bottom - 35), (right, bottom), color, cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            
            # Draw name and confidence
            text = f"{name}"
            cv2.putText(frame, text, (left + 6, bottom - 20), font, 0.5, (255, 255, 255), 1)
            
            # Draw status
            status_y = top - 10 if top > 30 else top + 20
            cv2.putText(frame, status_text, (left, status_y), font, 0.5, color, 1)
            
            if user_id and confidence > 0:
                conf_text = f"{confidence:.1f}%"
                cv2.putText(frame, conf_text, (left + 6, bottom - 6), font, 0.5, (255, 255, 255), 1)
        
        # Add timestamp overlay
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cv2.putText(frame, timestamp, (10, frame.shape[0] - 10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        return frame, attendance_marked
    
    def draw_cooldown_overlay(self, frame, current_time):
        """Draw cooldown overlay on frame"""
        global scan_cooldown_active, last_scan_time, cooldown_end_time
        
        if scan_cooldown_active:
            # Calculate remaining cooldown time
            remaining = max(0, cooldown_end_time - current_time)
            
            # Draw semi-transparent overlay
            overlay = frame.copy()
            cv2.rectangle(overlay, (0, 0), (frame.shape[1], frame.shape[0]), (0, 0, 0), cv2.FILLED)
            frame = cv2.addWeighted(overlay, 0.5, frame, 0.5, 0)
            
            # Draw cooldown message
            font = cv2.FONT_HERSHEY_DUPLEX
            text = f"SCANNER COOLING DOWN"
            text_size = cv2.getTextSize(text, font, 1.5, 2)[0]
            text_x = (frame.shape[1] - text_size[0]) // 2
            text_y = (frame.shape[0] - text_size[1]) // 2
            
            cv2.putText(frame, text, (text_x, text_y - 50), font, 1.5, (0, 255, 255), 2)
            
            # Draw countdown timer
            timer_text = f"{remaining:.1f}s"
            timer_size = cv2.getTextSize(timer_text, font, 3, 4)[0]
            timer_x = (frame.shape[1] - timer_size[0]) // 2
            timer_y = (frame.shape[0] + timer_size[1]) // 2
            
            cv2.putText(frame, timer_text, (timer_x, timer_y), font, 3, (0, 255, 0), 4)
            
            # Update scan progress status
            if remaining <= 0:
                scan_cooldown_active = False
                self.scan_in_progress = False
                self.attendance_marked = False
        
        return frame
    
    def mark_attendance(self, user_id, confidence):
        """Mark attendance in database"""
        try:
            result = db.execute_stored_procedure('sp_MarkAttendance', (user_id, confidence))
            
            if result and len(result) > 0:
                status = result[0][0]
                message = result[0][1]
                print(f"Attendance: {message} (User ID: {user_id})")
                return True
            return False
            
        except Exception as e:
            print(f"Error marking attendance: {e}")
            return False

def load_known_faces():
    """Load registered faces from database"""
    global known_faces, known_names, known_ids
    
    try:
        query = "SELECT user_id, name, face_encoding FROM Users WHERE is_active = 1"
        users = db.execute_query(query, fetch=True)
        
        known_faces = []
        known_names = []
        known_ids = []
        
        for user in users:
            user_id, name, encoding_binary = user
            
            # Decode face encoding
            face_encoding = face_utils.decode_from_database(encoding_binary)
            
            known_faces.append(face_encoding)
            known_names.append(name)
            known_ids.append(user_id)
        
        print(f"Loaded {len(known_faces)} registered users")
        
    except Exception as e:
        print(f"Error loading faces: {e}")

def generate_frames():
    """Generator function for video streaming"""
    global camera
    
    if camera is None:
        camera = CameraStream()
    
    while True:
        frame = camera.get_frame()
        
        if frame is None:
            continue
        
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        
        time.sleep(0.03)  # ~30 FPS

def cooldown_manager():
    """Background thread to manage cooldown timers"""
    while True:
        current_time = time.time()
        
        # Clean up old user cooldowns
        global user_cooldowns
        user_cooldowns = {uid: cooldown_time for uid, cooldown_time in user_cooldowns.items() 
                         if current_time - cooldown_time < RECOGNITION_COOLDOWN}
        
        time.sleep(1)

@app.route('/')
def index():
    """Main scanner page"""
    return render_template('scanner.html')

@app.route('/video_feed')
def video_feed():
    """Video streaming route"""
    return Response(generate_frames(),
                   mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/reload_faces')
def reload_faces():
    """Reload registered faces from database"""
    load_known_faces()
    return jsonify({'success': True, 'message': f'Loaded {len(known_faces)} users'})

@app.route('/today_attendance')
def today_attendance():
    """Get today's attendance records"""
    try:
        query = """
        SELECT u.name, a.check_in_time, a.status
        FROM Attendance a
        JOIN Users u ON a.user_id = u.user_id
        WHERE a.attendance_date = CAST(GETDATE() AS DATE)
        ORDER BY a.check_in_time DESC
        """
        
        records = db.execute_query(query, fetch=True)
        
        attendance_list = []
        for record in records:
            attendance_list.append({
                'name': record[0],
                'time': record[1].strftime('%H:%M:%S') if record[1] else '',
                'status': record[2]
            })
        
        return jsonify({'success': True, 'attendance': attendance_list})
        
    except Exception as e:
        print(f"Error fetching attendance: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/stats')
def get_stats():
    """Get attendance statistics"""
    try:
        query = """
        SELECT 
            (SELECT COUNT(*) FROM Users WHERE is_active = 1) as total_users,
            (SELECT COUNT(DISTINCT user_id) FROM Attendance 
             WHERE attendance_date = CAST(GETDATE() AS DATE)) as present_today,
            (SELECT COUNT(*) FROM Attendance 
             WHERE attendance_date = CAST(GETDATE() AS DATE)) as total_checkins
        """
        
        stats = db.execute_query(query, fetch=True)
        
        if stats and len(stats) > 0:
            return jsonify({
                'success': True,
                'total_users': stats[0][0] or 0,
                'present_today': stats[0][1] or 0,
                'total_checkins': stats[0][2] or 0
            })
        
        return jsonify({'success': True, 'total_users': 0, 'present_today': 0, 'total_checkins': 0})
        
    except Exception as e:
        print(f"Error fetching stats: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/scan_status')
def scan_status():
    """Get current scanner status"""
    global scan_cooldown_active, last_scan_time, SCAN_COOLDOWN
    current_time = time.time()
    
    if scan_cooldown_active:
        remaining = max(0, (last_scan_time + SCAN_COOLDOWN) - current_time)
        return jsonify({
            'status': 'cooldown',
            'can_scan': False,
            'cooldown_remaining': round(remaining, 1),
            'message': f'Scanner cooling down ({remaining:.1f}s remaining)'
        })
    else:
        return jsonify({
            'status': 'ready',
            'can_scan': True,
            'cooldown_remaining': 0,
            'message': 'Ready to scan'
        })

@app.route('/reset_cooldown')
def reset_cooldown():
    """Reset scanner cooldown (for testing)"""
    global scan_cooldown_active
    scan_cooldown_active = False
    return jsonify({'success': True, 'message': 'Cooldown reset'})

if __name__ == '__main__':
    print("=" * 60)
    print("FACE ATTENDANCE SYSTEM - BIOMETRIC SCANNER")
    print("=" * 60)
    print("Loading registered faces...")
    load_known_faces()
    
    # Start cooldown manager thread
    cooldown_thread = threading.Thread(target=cooldown_manager, daemon=True)
    cooldown_thread.start()
    
    print(f"Cooldown configured: {SCAN_COOLDOWN} seconds after each scan")
    print(f"User cooldown: {RECOGNITION_COOLDOWN} seconds between scans for same user")
    print("Starting scanner server...")
    print("Access at: http://localhost:5001")
    print("=" * 60)
    
    app.run(host='0.0.0.0', port=5001, debug=False, threaded=True)